"""Structural feedback tests."""
